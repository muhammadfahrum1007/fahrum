# autombf
Multi Brute Force Facebook With Auto Password

# Install
pkg install python2 git -y<br>
pip2 install requests<br>
git clone https://github.com/salism3/autombf<br>
cd autombf<br>
python2 autombf.py<br>







